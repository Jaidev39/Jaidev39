# YouTube still extraction

The supplied YouTube URL is embedded in the portfolio. The current environment could not fetch the YouTube video bytes, so no fake or guessed frames were added.

To extract actual frames, obtain the video file (or a copy you are permitted to use) and run:

```bash
python tools/extract_youtube_stills.py /path/to/video.mp4 --count 8
```

The stills will be written to `assets/media/youtube-stills/`.
