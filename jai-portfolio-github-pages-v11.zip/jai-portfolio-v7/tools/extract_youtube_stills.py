"""Extract real stills from a local copy of the supplied YouTube video.
Requires ffmpeg. Use a video file you are allowed to use.
Example: python tools/extract_youtube_stills.py video.mp4 --count 8
"""
import argparse, json, shutil, subprocess
from pathlib import Path
p=argparse.ArgumentParser()
p.add_argument('video',type=Path)
p.add_argument('--count',type=int,default=8)
p.add_argument('--out',type=Path,default=Path('assets/media/youtube-stills'))
a=p.parse_args()
if not a.video.exists(): raise SystemExit(f'Missing video: {a.video}')
if shutil.which('ffmpeg') is None or shutil.which('ffprobe') is None: raise SystemExit('ffmpeg and ffprobe are required')
a.out.mkdir(parents=True,exist_ok=True)
r=subprocess.run(['ffprobe','-v','error','-show_entries','format=duration','-of','json',str(a.video)],capture_output=True,text=True,check=True)
duration=float(json.loads(r.stdout)['format']['duration'])
fps=max(a.count/duration,0.001)
subprocess.run(['ffmpeg','-y','-i',str(a.video),'-vf',f'fps={fps}','-frames:v',str(a.count),str(a.out/'frame-%02d.jpg')],check=True)
print(f'Wrote {a.count} stills to {a.out}')
