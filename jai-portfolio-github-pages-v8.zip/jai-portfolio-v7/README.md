# Jaidev Portfolio — GitHub Pages V6

A static, university-application portfolio for Avirineni Jaidev Chowdary covering AI/computer vision projects, quantitative research, community impact, leadership, recognition, and a searchable activity + GitHub archive.

## Included
- Existing GitHub Pages structure preserved and upgraded from V5.
- Three research entries, including the completed Hybrid Deep Learning Stock Prediction research work with outdated future-December language removed.
- Public-safe evidence for GQMC 2026, YIP/RuralConnect, Plaksha Young Data Scientists, and Pan IIT Summit 2026.
- NUS evidence is described publicly while confidential recommendation/evaluation documents remain private.
- Supplied YouTube video embedded in the Media section.
- Supplied Google Drive archive linked in the Media section.
- Static HTML/CSS/JavaScript compatible with GitHub Pages.

## Deploy
Upload/replace the top-level `index.html`, `styles.css`, `script.js`, and the supporting folders in the existing `Jaidev39/Jaidev39` repository. Keep the repository and its existing history; do not delete it.

## Privacy
The Pan IIT Summit certificate included here is redacted to remove the private admission number. Private school/application and recommendation documents are not included in the public package.

## External sources
- YouTube: https://www.youtube.com/watch?v=pWwp-8fqV8M
- Google Drive: https://drive.google.com/drive/folders/1U4gu0Qbu1JC1fhEyrecKzGK-vz7uow28?usp=sharing

The Drive folder could not be mirrored automatically in this build environment, so its source URL is preserved for the next asset import.


## Imported media
The 30 image files from the supplied Google Drive export are included under `assets/media/drive-photo-archive/`. The supplied YouTube video is embedded; actual frame extraction requires local video bytes, and a helper is included under `tools/`.


### Video stills
Six selected full-resolution stills were extracted from the supplied `videoplayback.mp4` and added under `assets/media/video-stills/`.
